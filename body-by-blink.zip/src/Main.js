import React from 'react';
// import MainDesc from './components/MainContent/MainDesc';
import Counter from './components/CounterNo/Counter';
import HorizontalTab from './components/TabBlock/HorizontalTab';
import Skintone from './components/BaldingZones/SkinTones/Skintone';



function Main() {
  return (
    <>
    {/* <MainDesc/> */}
    {/* <Counter/> */}
    <HorizontalTab/>
    <Skintone/>
    </>
  )
}

export default Main;
